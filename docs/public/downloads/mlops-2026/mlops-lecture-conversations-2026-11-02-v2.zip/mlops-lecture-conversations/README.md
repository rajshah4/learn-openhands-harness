# MLOps saved conversations

This is the MLOps conference edition, separate from ODSC. It contains 12 primary lecture histories and three team-worker histories, plus the two original animated SVG outputs and shared prompt for Exercise 4. Exercise 5 is M5-A, the Pydantic migration and external HTTP replay. Its full capped history is retained, including the real checker failure, agent edit and passing replay. The cap is not a failed compatibility check, and no Stop hook executed in that recorded run.

## Import into your own Agent Canvas

Use a local npm installation of Agent Canvas. No model key is needed to inspect these histories. Stop your Canvas process before installing the import. From this extracted folder:

```sh
python3 import_into_canvas.py
python3 import_into_canvas.py --install
agent-canvas
```

The first command previews the destination. The second checks hashes, refuses overwrites, and copies records into the ordinary local Canvas store. On first launch, skip model setup if you only want to inspect the recordings. In the conversation list, choose View, Filter by tags, and `lecture=mlops2026`. Expand More if needed. Student-facing titles match package/selection.json and package/index.html.

Exercise 4 consists of original artifacts, not a Canvas conversation. Open the SVG files in package/animations/ and compare them against the shared prompt. The offline package/index.html links these artifacts and the full event evidence; use Canvas for the conversation walkthrough.

## Keep ODSC separate

MLOps has its own tag, importer receipt, archive name and workspaces. Import UUIDs use a deterministic MLOps namespace so ODSC and MLOps can coexist in one local store. The manifest preserves each original source UUID, and event IDs and relationships remain traceable. The source histories and ODSC package are never modified.

## Custom stores and recovery

The default store is ~/.openhands/agent-canvas/dev_conversations. For a custom local installation:

```sh
python3 import_into_canvas.py --store /absolute/path/dev_conversations --backend-url http://127.0.0.1:PORT
python3 import_into_canvas.py --store /absolute/path/dev_conversations --backend-url http://127.0.0.1:PORT --install
```

Point --backend-url to your actual local backend so the importer can verify it is stopped. The destination must be an ordinary conversations or dev_conversations directory. Symlinks, collisions, unexpected files and changed installed histories are rejected. Repeating an identical import verifies hashes and does not duplicate records.

The receipt `mlops-lecture-import.json` beside the store lists exactly what was installed and any historical type compatibility mappings. Keep the extracted original package. To remove the import, stop Canvas and remove only the imported IDs and workspace paths listed by this receipt; leave other conversations, credentials and settings alone. Never infer that an imported history is read-only because it has stopped. Imported agents have no executable tools, plugins, hooks or model credentials. Start a fresh conversation and workspace for a new exercise.

Import and ordinary Canvas startup were tested on macOS with Canvas 1.33.0 and Agent Server/SDK 1.58.1, using a fresh home and store with no model key. All 15 titles, tags and full histories loaded: 575 retained events, including the Workshop 5 cap. The `lecture=mlops2026` filter and the new failure/repair/pass history were inspected in the native UI. These are tested versions, not required install pins. Other versions, operating systems, Docker and remote imports are not qualified. See IMPORT-VERIFICATION.json for the checks.

This local bundle has not been published to GitHub or deployed to a remote site.
